import { Router } from "express";

export default {
  name: "Forex Academy",
  version: "1.0.0",
  slug: "forex-academy",
  navEntry: { icon: "💹", label: "Forex Academy", path: "/forex-academy" },

  routes() {
    const router = Router();

    router.get("/lessons", (req, res) => {
      res.json({ message: "TODO: return the forex-trading lesson catalog." });
    });

    router.get("/progress/:userId", (req, res) => {
      res.json({ message: "TODO: return this user's forex-academy progress." });
    });

    return router;
  },
};

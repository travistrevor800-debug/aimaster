import { Router } from "express";

export default {
  name: "Analytics",
  version: "1.0.0",
  slug: "analytics",
  navEntry: { icon: "📈", label: "Analytics", path: "/analytics" },

  routes() {
    const router = Router();

    router.get("/overview", (req, res) => {
      res.json({ message: "TODO: aggregate stats across modules (posts, learning progress, projects created, etc.)" });
    });

    return router;
  },
};

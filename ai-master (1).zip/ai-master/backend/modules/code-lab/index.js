import { Router } from "express";

// Languages Code Lab is meant to support - drives UI dropdowns etc.
export const SUPPORTED_LANGUAGES = [
  "JavaScript", "TypeScript", "Python", "Java", "C#",
  "C++", "Go", "Rust", "PHP", "SQL", "HTML/CSS", "Flutter (Dart)",
];

export const PROJECT_TEMPLATES = [
  "Portfolio website", "Blog", "REST API", "Mobile app",
  "AI assistant", "Discord bot", "Telegram bot", "Website chatbot",
  "E-commerce site", "Dashboard", "Task manager",
];

export default {
  name: "Code Lab",
  version: "1.0.0",
  slug: "code-lab",
  navEntry: { icon: "💻", label: "Code Lab", path: "/code-lab" },

  routes() {
    const router = Router();

    router.get("/languages", (req, res) => res.json({ languages: SUPPORTED_LANGUAGES }));
    router.get("/templates", (req, res) => res.json({ templates: PROJECT_TEMPLATES }));

    // Placeholder: wire these up to your LLM provider
    router.post("/explain", (req, res) => {
      res.json({ explanation: "TODO: send req.body.code to your LLM and return an explanation." });
    });

    router.post("/scaffold", (req, res) => {
      const { template, language } = req.body;
      res.json({ message: `TODO: generate a "${template}" starter project in ${language}.` });
    });

    router.post("/debug", (req, res) => {
      res.json({ fix: "TODO: send req.body.code + req.body.error to your LLM for a fix." });
    });

    return router;
  },
};

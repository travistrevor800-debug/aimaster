import { Router } from "express";
import eventBus from "../../core/eventBus.js";

export default {
  name: "Creator Studio",
  version: "1.0.0",
  slug: "creator-studio",
  navEntry: { icon: "🎬", label: "Creator Studio", path: "/creator-studio" },

  routes() {
    const router = Router();

    // Generate content from a topic/trend - wire this up to your LLM provider
    router.post("/generate", (req, res) => {
      const { topic, type } = req.body; // type: "hook" | "script" | "caption" | "thumbnail" | etc.
      res.json({
        message: `TODO: generate a "${type}" for topic "${topic}" via your LLM.`,
      });
    });

    router.post("/content-calendar", (req, res) => {
      res.json({ message: "TODO: generate a posting schedule/content calendar." });
    });

    return router;
  },

  async start() {
    // Listen for trends detected by social-sync, and auto-draft content ideas
    eventBus.on("trend:detected", (trend) => {
      console.log(`[Creator Studio] New trend received: ${trend.topic} (${trend.platform})`);
      // TODO: call your LLM here to draft a hook/script/caption for this trend,
      // then emit "content:drafted" for social-sync's scheduler to pick up.
    });
  },
};

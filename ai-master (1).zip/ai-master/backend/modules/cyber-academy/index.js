import { Router } from "express";

export default {
  name: "Cyber Academy",
  version: "1.0.0",
  slug: "cyber-academy",
  navEntry: { icon: "🛡", label: "Cyber Academy", path: "/cyber-academy" },

  routes() {
    const router = Router();

    router.get("/lessons", (req, res) => {
      res.json({ message: "TODO: return the cybersecurity lesson catalog." });
    });

    router.get("/progress/:userId", (req, res) => {
      res.json({ message: "TODO: return this user's cyber-academy progress." });
    });

    return router;
  },
};

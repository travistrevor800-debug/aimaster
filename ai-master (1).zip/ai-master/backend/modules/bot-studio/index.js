import { Router } from "express";

export default {
  name: "Bot Studio",
  version: "1.0.0",
  slug: "bot-studio",
  navEntry: { icon: "🛠", label: "Bot Studio", path: "/bot-studio" },

  routes() {
    const router = Router();

    router.post("/discord/scaffold", (req, res) => {
      res.json({ message: "TODO: generate a Discord bot starter project." });
    });

    router.post("/telegram/scaffold", (req, res) => {
      res.json({ message: "TODO: generate a Telegram bot starter project." });
    });

    router.post("/webchat/scaffold", (req, res) => {
      res.json({ message: "TODO: generate a website chatbot starter project." });
    });

    return router;
  },
};

import { Router } from "express";
import { getMemory, updateMemory } from "./memory.js";

export default {
  name: "AI Assistant",
  version: "1.0.0",
  slug: "ai-assistant",
  navEntry: { icon: "🤖", label: "AI Assistant", path: "/ai-assistant" },

  routes() {
    const router = Router();

    // Fetch stored user preferences (languages, learning progress, etc.)
    router.get("/memory/:userId", (req, res) => {
      res.json(getMemory(req.params.userId));
    });

    router.post("/memory/:userId", (req, res) => {
      const updated = updateMemory(req.params.userId, req.body);
      res.json(updated);
    });

    // Placeholder for actual chat/completion endpoint
    router.post("/chat", (req, res) => {
      const { message } = req.body;
      res.json({ reply: `TODO: wire this up to your LLM provider. You said: "${message}"` });
    });

    return router;
  },

  async start() {
    console.log("AI Assistant module ready.");
  },
};

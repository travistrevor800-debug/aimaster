import { Router } from "express";

export default {
  name: "Settings",
  version: "1.0.0",
  slug: "settings",
  navEntry: { icon: "⚙", label: "Settings", path: "/settings" },

  routes() {
    const router = Router();

    router.get("/:userId", (req, res) => {
      res.json({ message: "TODO: return stored user settings from the database module." });
    });

    router.put("/:userId", (req, res) => {
      res.json({ message: "TODO: persist req.body as this user's settings." });
    });

    return router;
  },
};

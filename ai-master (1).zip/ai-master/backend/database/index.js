// Placeholder database connection. Replace with a real client once you've
// picked a database (Postgres, MongoDB, SQLite, etc).
//
// Example with Postgres (pg):
//
//   import pg from "pg";
//   const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
//   export default pool;

export default {
  async connect() {
    console.log("[Database] TODO: connect to a real database.");
  },
};

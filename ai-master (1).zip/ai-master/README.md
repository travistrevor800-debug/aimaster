# AI Master

A modular learning/productivity platform. Every feature - AI Assistant,
Cyber Academy, Forex Academy, Code Lab, Creator Studio, Bot Studio,
Social Sync, Analytics, Settings - is an installable backend module, so new
capabilities can be added without touching existing ones.

## What's in this scaffold

```
backend/
├── core/
│   ├── moduleLoader.js     # discovers + loads modules from /modules at boot
│   ├── moduleContract.md   # the shape every module must follow
│   └── eventBus.js         # lets modules talk to each other without direct imports
├── modules/
│   ├── ai-assistant/       # chat endpoint + per-user preference memory (stubs)
│   ├── cyber-academy/      # lesson catalog + progress (stubs)
│   ├── forex-academy/      # lesson catalog + progress (stubs)
│   ├── creator-studio/     # content generation, listens for trends (stubs)
│   ├── bot-studio/         # Discord/Telegram/webchat bot scaffolding (stubs)
│   ├── code-lab/           # multi-language explain/scaffold/debug (stubs)
│   ├── social-sync/        # trend detection + cross-platform auto-posting (stubs)
│   ├── analytics/          # cross-module stats (stub)
│   └── settings/           # per-user settings (stub)
├── api/                    # reserved for shared/cross-cutting routes
├── database/               # placeholder DB connection - swap in a real client
├── storage/                # reserved for file/media storage
├── server.js               # Express app entry point
└── package.json

frontend/                   # not yet built - see "Next step" below

DEPLOYMENT.md                # full step-by-step deploy guide (Railway, Render, Fly.io, VPS)
render.yaml                  # one-click Render deploy config
backend/Dockerfile           # for Fly.io or any Docker host
backend/.env.example          # env vars you'll need to set on your host
```

Every module file is a **working stub**: it wires up correctly with the
module loader and returns real (if placeholder) JSON, but the actual
AI-generation and third-party API calls are marked `TODO` for you to fill in
with your chosen LLM provider and platform credentials.

## Running it

```bash
cd backend
npm install
npm run dev
```

Then check:
- `GET http://localhost:4000/api/health` - confirms modules loaded
- `GET http://localhost:4000/api/dashboard/nav` - nav entries for every loaded module
- `GET http://localhost:4000/api/<module-slug>/...` - each module's own routes

## Deploying

See `DEPLOYMENT.md` for the full step-by-step guide (Railway, Render, Fly.io,
or a plain VPS), including database setup, environment variables, and a
production checklist.

## Adding a new module

1. Create `backend/modules/<your-module>/index.js`
2. Follow the shape in `core/moduleContract.md`
3. Restart the server - ModuleLoader picks it up automatically, no other
   files need to change.

## Social Sync - trend detection & auto-posting

This is the newest and most involved module: it's meant to pull trending
topics across platforms, hand them to Creator Studio to draft content, then
auto-post the result back out. Read
`backend/modules/social-sync/connectors/README.md` before building this out -
each platform (YouTube, X, Instagram, TikTok) has different API access,
approval requirements, and trend-data availability, and that will shape how
much of this you can automate on day one vs. later.

## Next step: the frontend

No frontend is scaffolded yet since that choice (React web dashboard vs.
Flutter mobile app) is still open. Once you decide, the natural next step is
a dashboard that renders nav items from `GET /api/dashboard/nav` and calls
each module's routes - the backend is already shaped to support that without
changes.

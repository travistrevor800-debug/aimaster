# Deployment Guide

Step-by-step path from this scaffold to a live, deployed backend.

## 1. Run it locally first

```bash
cd backend
npm install
cp .env.example .env
npm run dev
```

Check `http://localhost:4000/api/health` - it should return `modulesLoaded: 9`.
Do not move to deployment until this works locally.

## 2. Put it in version control

```bash
cd ai-master
git init
git add .
git commit -m "Initial AI Master backend scaffold"
```

Create a repo on GitHub (or GitLab) and push:

```bash
git remote add origin <your-repo-url>
git branch -M main
git push -u origin main
```

`.env` is already excluded via `.gitignore` - never commit real secrets.

## 3. Choose a host

| Option | Good for | Cost |
|---|---|---|
| **Railway** | Fastest setup, built-in DB add-ons | Free tier, then usage-based |
| **Render** | Auto-deploys on git push, `render.yaml` included | Free tier (spins down when idle) |
| **Fly.io** | More control, Docker-based (Dockerfile included) | Free tier, usage-based |
| **VPS** (DigitalOcean/Hetzner) | Full control, cheapest at scale | ~$5-6/mo, more setup |

### Option A: Railway
1. Go to railway.app -> New Project -> Deploy from GitHub repo
2. Select your repo
3. Set **root directory** to `backend`
4. Railway auto-detects Node and runs `npm start`
5. Add environment variables (see step 5 below)
6. Add a Postgres database: New -> Database -> PostgreSQL - Railway sets `DATABASE_URL` for you automatically

### Option B: Render
1. Go to render.com -> New -> Blueprint
2. Connect your repo - Render will read `render.yaml` at the repo root automatically
3. Fill in the env vars it prompts for (`DATABASE_URL`, `ANTHROPIC_API_KEY`)
4. Add a Postgres instance from Render's dashboard if you don't have one yet, copy its connection string into `DATABASE_URL`

### Option C: Fly.io (Docker-based)
```bash
cd backend
fly launch          # detects the Dockerfile, asks a few setup questions
fly secrets set ANTHROPIC_API_KEY=... DATABASE_URL=...
fly deploy
```

### Option D: A VPS
1. Provision a small Ubuntu droplet/instance
2. SSH in, install Node 20 and git
3. `git clone <your-repo-url> && cd ai-master/backend`
4. `npm install --omit=dev`
5. Set env vars (`export $(cat .env | xargs)` or use a process manager's env support)
6. Run with a process manager so it survives reboots/crashes:
   ```bash
   npm install -g pm2
   pm2 start server.js --name ai-master
   pm2 save
   pm2 startup
   ```
7. Put Nginx in front as a reverse proxy (see step 7)

## 4. Add a real database

`backend/database/index.js` is currently a stub. Once you have a `DATABASE_URL`
(from Railway/Render's managed Postgres, or your own), swap it for a real
client, e.g.:

```bash
npm install pg
```

```js
// backend/database/index.js
import pg from "pg";
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
export default pool;
```

Then replace the in-memory stores in `modules/ai-assistant/memory.js` and
`modules/social-sync/scheduler.js` with real queries against this pool.

## 5. Set environment variables on your host

Every option above has an "Environment Variables" or "Secrets" panel in its
dashboard (or `fly secrets set` on Fly.io). Add each key from
`backend/.env.example` with its real value. Never put real secrets in git.

## 6. Deploy

- Railway/Render: pushing to your `main` branch auto-triggers a new deploy
  once the project is connected.
- Fly.io: `fly deploy` from your local machine (or hook up GitHub Actions
  for auto-deploy on push).
- VPS: `git pull && pm2 restart ai-master` after each change.

You'll get a live URL, e.g. `https://ai-master-backend.up.railway.app`.

## 7. Point a custom domain at it (optional)

1. Buy a domain (Namecheap, Google Domains, etc.)
2. In your host's dashboard, add a "Custom Domain" and follow the CNAME/A
   record instructions it gives you
3. On a VPS, instead configure Nginx as a reverse proxy:
   ```nginx
   server {
       listen 80;
       server_name yourdomain.com;
       location / {
           proxy_pass http://localhost:4000;
           proxy_set_header Host $host;
       }
   }
   ```
   Then use Certbot for a free HTTPS certificate.

## 8. The frontend

No frontend exists yet in this scaffold - only the API. Once you decide
between React and Flutter:

- **React**: deploy separately on Vercel or Netlify. Point it at your
  backend's live URL (e.g. via an `.env` variable like `VITE_API_URL`).
- **Flutter**: builds to mobile (and optionally web). It calls the same
  backend URL over HTTPS - no backend changes needed.

The backend is already shaped for this: `GET /api/dashboard/nav` returns
nav entries for whatever modules are loaded, and each module exposes its
own routes under `/api/<module-slug>/...`.

## 9. After deploying - production checklist

- [ ] `.env` values are set on the host, not committed to git
- [ ] Real database connected (not the in-memory stub)
- [ ] `/api/health` returns the expected module count on the live URL
- [ ] CORS configured on `server.js` if your frontend is on a different domain
      (`npm install cors`, then `app.use(cors({ origin: "https://yourfrontend.com" }))`)
- [ ] HTTPS enabled (automatic on Railway/Render/Fly, manual via Certbot on a VPS)
- [ ] Social Sync connectors only go live once you've completed each
      platform's API approval process - see
      `backend/modules/social-sync/connectors/README.md`
